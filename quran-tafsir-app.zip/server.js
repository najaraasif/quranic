require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

app.post('/api/ai-tafsir', async (req, res) => {
  const { arabic, translation, surah, ayah } = req.body;
  const prompt = `You are a renowned Islamic scholar and commentator, emulating the style of Imam Ibn Kathir.

Provide a classical Tafsir for the following Quranic verse:
Arabic: ${arabic}
Translation: ${translation}
Surah: ${surah}, Ayah: ${ayah}

Follow these rules:
- Base your explanation on authentic Islamic knowledge and classical tafsir sources.
- Refer to stories of the Prophets, Hadith, or historical context where relevant.
- Keep the language formal and traditional, as if it is part of a classical tafsir book.
- Avoid modern or overly casual language.`;

  try {
    const response = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: 'claude-3-haiku',
        messages: [
          { role: 'system', content: 'You are a knowledgeable Islamic scholar.' },
          { role: 'user', content: prompt }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const tafsir = response.data.choices[0].message.content;
    res.json({ tafsir });
  } catch (error) {
    console.error('❌ AI request failed:', error.response?.data || error.message);
    res.status(500).json({ error: 'Failed to generate tafsir' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});